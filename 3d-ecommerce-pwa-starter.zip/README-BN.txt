NOVA 3D E-commerce PWA Demo — ফোনে ব্যবহার করার নির্দেশনা

এই ZIP-এর মধ্যে আছে:
- index.html: ওয়েবসাইটের পেজ
- style.css: ডিজাইন ও responsive layout
- app.js: product filter, demo cart, install prompt
- manifest.webmanifest: PWA app metadata
- sw.js: basic offline cache
- icons/: app icons

গুরুত্বপূর্ণ:
1. এটি একটি FRONT-END DEMO; এখনো আসল অর্ডার, লগইন, inventory বা payment gateway নেই।
2. বাস্তব অর্ডার ও পেমেন্ট নেওয়ার আগে secure backend/database এবং payment provider integration করতে হবে।
3. PWA install-এর জন্য সাইটটি HTTPS-এ host করুন (GitHub Pages-এ HTTPS চালু রাখুন)।
4. Android Chrome-এ সাইট খুলে ⋮ মেনু > Install app অথবা Add to Home screen চাপুন। ব্রাউজারভেদে শব্দ আলাদা হতে পারে।
5. GitHub Pages-এ ব্যবহার: repository-তে ZIP extract করে ফাইলগুলো upload করুন; Settings > Pages থেকে branch/folder publish করুন।
6. app icon ফাইলগুলো এই starter-এর সঙ্গে অন্তর্ভুক্ত।
7. Demo products, NOVA নাম, দাম ও কনটেন্ট ক্লায়েন্টের তথ্য দিয়ে বদলান। ডেমো ব্র্যান্ডকে ক্লায়েন্টের ব্র্যান্ড বলে উপস্থাপন করবেন না।

Phone-only workflow:
- ZIP ডাউনলোড ও extract করুন।
- GitHub-এ নতুন public repository বানান।
- Extract করা ফাইল ও icons folder upload করুন।
- Settings > Pages > Deploy from a branch > main / root নির্বাচন করুন।
- প্রকাশিত HTTPS link ফোনে খুলুন; Chrome menu থেকে Install app/Add to Home screen দিন।

3D note:
Hero-তে CSS-based 3D-inspired illustration আছে, external 3D model নয়। Real interactive 3D model যোগ করতে Three.js/GLB model integration আলাদা কাজ।
