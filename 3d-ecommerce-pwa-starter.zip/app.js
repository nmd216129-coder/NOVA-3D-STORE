const products = [
  {id:1,name:"Air Shift Runner",category:"Shoes",price:4890,desc:"Lightweight / Future form",symbol:"👟",label:"BESTSELLER"},
  {id:2,name:"Orbit Street Low",category:"Shoes",price:3690,desc:"Everyday / Bold comfort",symbol:"🥾",label:"NEW DROP"},
  {id:3,name:"Nova Utility Pack",category:"Accessories",price:2190,desc:"Carry smart / Go further",symbol:"🎒",label:"LIMITED"},
  {id:4,name:"Pulse Studio Headphones",category:"Accessories",price:3290,desc:"Immersive / Clean sound",symbol:"🎧",label:"STUDIO PICK"},
  {id:5,name:"Cloud Form Sneaker",category:"Shoes",price:5290,desc:"Soft landing / Sharp look",symbol:"👟",label:"NEW COLOR"},
  {id:6,name:"Arc Smart Watch",category:"Accessories",price:5990,desc:"Minimal / Built for motion",symbol:"⌚",label:"FEATURED"}
];
let cart = JSON.parse(localStorage.getItem("nova-cart") || "[]");
let activeFilter = "All";
const grid = document.querySelector("#productGrid");
const cartDrawer = document.querySelector("#cartDrawer");
const overlay = document.querySelector("#overlay");
const toast = document.querySelector("#toast");
let toastTimer;

function money(n){return "৳"+n.toLocaleString("en-BD")}
function showToast(msg){toast.textContent=msg;toast.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove("show"),2300)}
function renderProducts(){
  const filtered = products.filter(p=>activeFilter==="All"||p.category===activeFilter);
  grid.innerHTML = filtered.map(p=>`<article class="product-card"><div class="product-visual"><span class="product-label">${p.label}</span><span class="product-symbol" aria-hidden="true">${p.symbol}</span></div><div class="product-info"><h3>${p.name}</h3><p>${p.desc}</p><div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">+ Add to bag</button></div></div></article>`).join("");
}
function renderCart(){
  document.querySelector("#cartCount").textContent=cart.reduce((n,item)=>n+item.qty,0);
  document.querySelector("#cartTotal").textContent=money(cart.reduce((n,item)=>n+item.price*item.qty,0));
  document.querySelector("#cartItems").innerHTML=cart.length?cart.map(item=>`<div class="cart-row"><div><strong>${item.name}</strong><small>${money(item.price)} × ${item.qty}</small></div><div><strong>${money(item.price*item.qty)}</strong><br><button data-remove="${item.id}">Remove</button></div></div>`).join(""):'<p class="empty-cart">Your bag is waiting for something great.</p>';
  localStorage.setItem("nova-cart",JSON.stringify(cart));
}
function openCart(){cartDrawer.classList.add("open");overlay.classList.add("open");cartDrawer.setAttribute("aria-hidden","false")}
function closeCart(){cartDrawer.classList.remove("open");overlay.classList.remove("open");cartDrawer.setAttribute("aria-hidden","true")}
document.querySelector("#productGrid").addEventListener("click",e=>{const btn=e.target.closest("[data-add]");if(!btn)return;const p=products.find(x=>x.id===Number(btn.dataset.add));const existing=cart.find(x=>x.id===p.id);existing?existing.qty++:cart.push({...p,qty:1});renderCart();showToast("Added to your bag")});
document.querySelector("#cartItems").addEventListener("click",e=>{const btn=e.target.closest("[data-remove]");if(!btn)return;cart=cart.filter(x=>x.id!==Number(btn.dataset.remove));renderCart()});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");activeFilter=btn.dataset.filter;renderProducts()}));
document.querySelector("#cartToggle").addEventListener("click",openCart);
document.querySelector("#closeCart").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
document.querySelector("#checkoutBtn").addEventListener("click",()=>showToast("Demo only — connect a secure checkout before launch."));
renderProducts();renderCart();

let deferredPrompt;
const installBtn=document.querySelector("#installBtn");
window.addEventListener("beforeinstallprompt",event=>{event.preventDefault();deferredPrompt=event;installBtn.hidden=false});
installBtn.addEventListener("click",async()=>{if(!deferredPrompt){showToast("Use your browser menu: Add to Home screen");return}deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installBtn.hidden=true});
window.addEventListener("appinstalled",()=>{installBtn.hidden=true;showToast("NOVA installed")});
if("serviceWorker" in navigator && location.protocol.startsWith("http")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
