NOVA — Premium General E-commerce Demo
ফাইল: index.html (structure), style.css (white/cream responsive design), app.js (products, filters, cart, interactive CSS 3D tilt), manifest.webmanifest (PWA settings), sw.js (basic offline cache), icons/ (app icons).
GitHub: upload every file to repository root and upload icons folder with both PNGs. Settings > Pages > Deploy from a branch > main > /(root) > Save. After publishing, open the HTTPS URL in Chrome and choose Install app or Add to Home screen.
Important: this is a frontend portfolio demo. It does not process real orders, payments, email or database writes. The product visuals are CSS illustrations with interactive perspective tilt, not full WebGL 3D models or real product photography. Replace with client-approved images and connect a secure backend/payment provider before a real launch. Google Fonts uses internet; fallback fonts work offline.


নতুন Fashion Hero: শুরুতে দুইটি ফ্যাশন এডিটোরিয়াল ছবি, cream/white styling এবং subtle CSS animation যোগ করা হয়েছে। ছবিগুলো দেখাতে ইন্টারনেট সংযোগ দরকার। এগুলো ডেমো ছবি; ক্লায়েন্টের অনুমতি নিয়ে নিজস্ব ছবি ব্যবহার করুন।
